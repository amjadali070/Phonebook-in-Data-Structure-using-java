The README file contains the instructions how to run the project.

Project Name: PhoneBook

What is PhoneBook ?
PhoneBook is book or database used for storing entries called contacts Each contact entry usually consists of a few standard fields for eg name, address, phone no. etc The operations like adding, sorting, searching, deleting etc is done on the entries
Why PhoneBook ?
A software PhoneBook is easier to use than a paper PhoneBook a variety of operations can be performed easily on it. PhoneBook is thing which is useful to all users as being social entities from a child to an old man all have contacts and it provides an easy tool to manage contacts.

The PhoneBook prject is created in Data Structure using java programming language

The project folder contains the .exe file of project, by clicking that file user can easily run the project. If you want to run this in any IDE you must have to install Eclipse or NetBeans, and then download project files from github by clicking on fallowing provided link. Then import our project in IDE and then simply execute the project. If you want to watch the explaination provided by the developers so go and watch youtube video by provided link.

Features.
Register - New user can register his account
LogIn	 - After registration user can LogIn by using UserName and Password
Save New Contact - By filling the required field user can add new contact
View All - User Can view all saved contacts
Edit     - User Can Edit saved contacts
Delete 	 - User Can delete saved contacts
Sort A-Z - User Can Sort his/her saved contacts in accending order
Recent Delete - User Can see his/her recent deleted contacts
Recent Search - User Can see his/her recent searched contacts
LogOut	- By clinking logout user will be logged out from the program.

Video Link: https://drive.google.com/file/d/15IpXybm2Hgn7o132HHQm1cHRYNYmYzMi/view?usp=sharing
---- Thanks ----
Developed By: Muhammad Tahir and Amjad Ali (Students of Sukkur IBA University)
